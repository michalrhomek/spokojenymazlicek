~ Total Import PRO ~
By HostJars

Thanks for purchasing this module!

If you have any questions then you can message us in the PrestaShop Addons messaging center. In our helpdesk we also offer lots of useful tutorials and documentation there.
We have detailed guides for each step to help you get up and running.

If you have questions after reading our documentation, feel free to contact our support team.

We provide bug fixes free of charge. We can also quote you for customization if you would like a specific feature added to your installation.